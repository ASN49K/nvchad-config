local M = {
  events = {},
  ns = 1,
}

return M
