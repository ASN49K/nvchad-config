return { -- this file is generated from lua/nvim-web-devicons/default/icons_by_window_manager.lua, please do not edit
  ["awesomewm"]     = { icon = "", color = "#3E4651", cterm_color = "238", name = "awesome"       },
  ["bspwm"]         = { icon = "", color = "#4F4F4F", cterm_color = "239", name = "BSPWM"         },
  ["dwm"]           = { icon = "", color = "#0D5980", cterm_color = "24",  name = "dwm"           },
  ["enlightenment"] = { icon = "", color = "#333333", cterm_color = "236", name = "Enlightenment" },
  ["fluxbox"]       = { icon = "", color = "#404040", cterm_color = "238", name = "Fluxbox"       },
  ["hyprland"]      = { icon = "", color = "#008082", cterm_color = "30",  name = "Hyprland"      },
  ["i3"]            = { icon = "", color = "#2E2F30", cterm_color = "236", name = "i3"            },
  ["jwm"]           = { icon = "", color = "#005A9A", cterm_color = "25",  name = "JWM"           },
  ["qtile"]         = { icon = "", color = "#333333", cterm_color = "236", name = "Qtile"         },
  ["river"]         = { icon = "", color = "#000000", cterm_color = "16",  name = "river"         },
  ["sway"]          = { icon = "", color = "#4E5815", cterm_color = "58",  name = "Sway"          },
  ["xmonad"]        = { icon = "", color = "#A9333E", cterm_color = "131", name = "xmonad"        },
} --[[@as table<string, Icon>]]
